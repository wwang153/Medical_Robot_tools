import numpy as np
from loadData import LoadData
from solvers import Solvers
from transformation_solvers import Transformation
from sklearn.neighbors import KDTree
import test
ld = LoadData()
sol = Solvers()
trans = Transformation()

def registration_Helper(problemNum, index, y, fileIndex, dddd):
    '''
    Using point cloud registration to get F
    @param problemNum: problem number 3 or 4.
    @param index: file index A or B.
    @param dddd: unknown or debug.
    @param y: a or b.
    @param fileIndex: A to J.
    @param dddd: debug or unknown.
    @return Flist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    _, _, num_frame = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    Flist = []
    markers, tips = ld.loadProbelmBody(problemNum, index)
    for i in range(num_frame):
        Flist.append(sol.solvePointCloudReg_Arun(markers, y[6 * i:6 * (i + 1)]))
    return Flist, tips

def getFA(problemNum, fileIndex, dddd):
    '''
    Using point cloud registration to get FA
    @param problemNum: problem number 3 or 4.
    @param index: file index A or B.
    @param dddd: unknown or debug.
    @return FAlist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    a, _, numFrames = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    FAlist, Atips = registration_Helper(problemNum, 'A', a, fileIndex, dddd)
    return FAlist, Atips, numFrames

def getFB(problemNum, fileIndex, dddd):
    '''
    Using point cloud registration to get FB
    @param problemNum: problem number 3 or 4.
    @param fileIndex: file index A to J.
    @param dddd: unknown or debug.
    @return FAlist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    _, b, numFrames = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    FAlist, Btips = registration_Helper(problemNum, 'B', b, fileIndex, dddd)
    return FAlist, Btips, numFrames

def getdk(problemNum, fileIndex,dddd):
    '''
    @return dk: dk = FB^-1 * FA * Atip
    '''
    FA, Atip, num_frame = getFA(problemNum, fileIndex, dddd)
    FB, _, _ = getFB(problemNum, fileIndex, dddd)
    for i in range(num_frame):
        if i == 0:
            dk0 = np.mat(trans.mulF_p(trans.mulF_F(trans.inv_F(FB[0]), FA[0]), Atip.T).T)
        else:
            dk = np.vstack((dk0, np.mat(trans.mulF_p(trans.mulF_F(trans.inv_F(FB[i]), FA[i]), Atip.T).T)))
            dk0 = dk
    return dk

def getsk(problemNum, fileIndex ,dddd):
    '''
    @return ck: ck = F_reg * dk
    '''
    #initialize Freg = I
    R_reg = np.identity(3)
    p_reg = np.mat([[0],[0],[0]])
    F_reg = [R_reg, p_reg]
    dk = getdk(problemNum, fileIndex, dddd)
    for i in range(len(dk)):
        if i == 0:
            sk0 = np.mat(trans.mulF_p(F_reg, dk[0].T)).T
        else:
            sk = np.vstack((sk0, np.mat(trans.mulF_p(F_reg, dk[i].T)).T))
            sk0 = sk
    return sk

def getTriangles(problemNum):
    '''
    @param problemNum: problem 3 or 4.
    @return triangles: a list of 3x3 matrices represent 3 points
    of triangles. [point1, point2, point3]
    '''

    triangles = []
    vertcies, indices = ld.loadMesh(problemNum)
    for i in range(len(indices)):
        qindex, rindex, pindex = indices[i, 0], indices[i, 1], indices[i, 2]
        triangle = np.hstack((vertcies[qindex].T, np.hstack((vertcies[rindex].T, vertcies[pindex].T))))
        triangles.append(triangle)
    return triangles

def findClosestPoint(problemNum, fileIndex, dddd):
    '''
    Find closest point using triangles that:
    a-p ~= lambda(q-p) + miu(r-p)
    get lambda and miu by lstsq
    c = p + lambda(q-p) + miu(r-p)
    on certain condition get the c as closest, otherwise continue search
    @param fileIndex: A or B.
    @param problemNum: problem 3 or 4.
    @param dddd: unknown or debug.
    @return: matrix of closest points c
    '''
    ck = []
    sk = getsk(problemNum, fileIndex, dddd)
    triangles = getTriangles(problemNum)
    for i in range(len(sk)):
        closestDis = float('inf')
        ct = []
        for j in range(len(triangles)):
            q, r, p = triangles[j][:, 0], triangles[j][:, 1], triangles[j][:, 2]
            ai = sk[i].T
            #using lstsq to solve lambda and miu
            A = np.hstack(((q - p), (r - p)))
            B = ai - p
            coeff = np.linalg.lstsq(A, B, None)[0]
            ci = A * coeff + p
            if coeff[0] >= 0 and coeff[1] >= 0 and np.sum(coeff) <= 1:
                ct.append(ci)
            elif coeff[0] < 0:
                ct.append(projectOnSeg(ci, r, p))
            elif coeff[1] < 0:
                ct.append(projectOnSeg(ci, p, q))
            elif np.sum(coeff) > 1:
                ct.append(projectOnSeg(ci, q, r))
        # search in brute way
        # for k in range(len(ct)):
        #     if np.linalg.norm(ai - ct[k]) < closestDis:
        #         closestPoint = ct[k]
        #         closestDis = np.linalg.norm(ai - ct[k])
        # ck.append(closestPoint.T)

        # using KDTree to search
        for n in range(len(ct)):
            if n == 0:
                c0 = ct[n]
            else:
                c = np.hstack((c0, ct[n]))
                c0 = c
        tree = KDTree(c.T, leaf_size=5)
        dis, index = tree.query(ai.T)
        closestPoint = ct[index[0,0]]
        ck.append(closestPoint.T)

    # put ck in np matrix
    for i in range(len(ck)):
        if i == 0:
            c0 = ck[i]
        else:
            c = np.vstack((c0, ck[i]))
            c0 = c
    # difference between sk and c
    for i in range(len(ck)):
        if i == 0:
            diff0 = np.linalg.norm(sk[i] - c[i])
        else:
            diff = np.vstack((diff0, np.linalg.norm(sk[i] - c[i])))
            diff0 = diff
    return c, diff

def projectOnSeg(c, a, b):
    '''
    @param c: point on the border of triangle.
    @param a: one of 3 vertices in triangle.
    @param b: one of 3 vertices in triangle.
    @return c_star
    '''
    la = ((c - a).T*(b - a)) / ((b - a).T*(b - a))
    la_seg = max(0, min(la, 1))
    c_star = a + (b - a) * la_seg
    return c_star

def outputAll():
    '''
    Generate all outputs in OUTPUT folder.
    '''
    index = {'A': 'debug', 'B': 'debug', 'C': 'debug', 'D': 'debug', 'E': 'debug', 'F': 'debug',
             'G': 'unknown', 'H': 'unknown', 'J': 'unknown'}
    for i in index.items():
        c, diff = findClosestPoint(3, i[0], i[1])
        sk = getsk(3, i[0], i[1])
        # np.set_printoptions(precision=3, suppress=True)
        content = np.hstack((sk, np.hstack((c, diff))))
        ld.OutputData3(i[0], content)

if __name__ == '__main__':
    # outputAll()
    print('Done!')