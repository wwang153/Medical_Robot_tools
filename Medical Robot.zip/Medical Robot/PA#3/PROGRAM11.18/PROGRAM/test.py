from loadData import LoadData
import numpy as np
import program3 as p3
from transformation_solvers import Transformation
from sklearn.neighbors import KDTree

trans = Transformation()
ld = LoadData()

def testPB():
    '''
    test method loadProbelmBody in loadData.py
    '''
    markers, tips = ld.loadProbelmBody(3, 'A')
    print(markers,'\n',tips)

def testSR():
    '''
    test method loadSampleReadings in loadData.py
    '''
    NA, NB, numFrames = ld.loadSampleReadings(3, 'G', 'unknown')
    print(NA,'\n', NB)
    print(NA.shape,'\n', numFrames)

def testRH():
    '''
    test method registration_Helper in program3.py
    '''
    a, b = ld.loadSampleReadings(3, 'A', 'debug')
    markers, tips = ld.loadProbelmBody(3, 'A')
    Flist, tips = p3.registration_Helper(3, 'A', a)
    # print(len(Flist), Flist[0])
    a_test = trans.mulF_p(Flist[0], markers[0].T)
    print('a - a_test=', a[0] - a_test.T)

def testGetF():
    '''
    test method getF in program3.py
    '''
    FA, _ = p3.getFA(3, 'A', 'debug')
    FB, _ = p3.getFB(3, 'A', 'debug')
    print('FA', FA[0], '\n', 'FB', FB[0])

def testGetdk():
    '''
    test method getdk in program3.py
    '''
    dk = p3.getdk(3, 'G', 'Unknown')
    print('\n','dk', dk)

def testGetsk():
    '''
    test method getsk in program3.py
    '''
    sk = p3.getsk(3, 'G', 'Unknown')
    print('\n',sk.shape)

def testloadMesh():
    '''
    test method loadMesh in loadData.py
    '''
    vertices, indicies = ld.loadMesh(3)
    print('\n',vertices[0],'\n',indicies[0])
    x,y,z = indicies[0,0],indicies[0,1],indicies[0,2]
    print('x,y,z',x,y,z)

def testgetTriangles():
    '''
    test getTriangles in program3.py
    '''
    vertices, _ = ld.loadMesh(3)
    print('1st triangle should be', [vertices[12].T, vertices[19].T, vertices[1].T])
    triangles = p3.getTriangles(3)
    print(len(triangles), 'triangles:','\n', triangles[0][:,0])

def testfindClosestPoint(fileIndex, dddd):
    '''
    test findClosestPoint in program3.py
    '''
    np.set_printoptions(precision=3, suppress=True)
    c, diff = p3.findClosestPoint(3, fileIndex, dddd)
    # print('c', c, '\n', 'diff:', diff)
    print(np.hstack((c, diff)))
    
def closept():
    '''
    unit test of findClosestPoint

    '''
    sk = np.array([[2.,0.,0.]])
    ck = []
    triangles = [np.matrix([[0.,0.,0.],[-1.,2.,-1.],[-1.,-1.,2.]]),np.matrix([[1.,1.,1.],[-1.,2.,-1.],[-1.,-1.,2.]]),np.matrix([[2.,2.,2.],[-1.,2.,-1.],[-1.,-1.,2.]]),np.matrix([[3.,3.,3.],[-1.,2.,-1.],[-1.,-1.,2.]]),np.matrix([[4.,4.,4.],[-1.,2.,-1.],[-1.,-1.,2.]])]
    # print(triangles)
    for i in range(len(sk)):
        closestDis = float('inf')
        for j in range(len(triangles)):
            q, r, p = triangles[j][:, 0], triangles[j][:, 1], triangles[j][:, 2]
            ai = sk[i].T
            # print('q',q,'r',r,'p',p)
            #using lstsq to solve lambda and miu
            A = np.hstack(((q - p), (r - p)))
            B = ai - p
            # print(A,B)
            coeff = np.linalg.lstsq(A, B, None)[0]
            ci = A * coeff + p
            print(ci)

def testKDTree():
    '''
    test the KDTree data structure
    '''
    triangles = p3.getTriangles(3)
    sk = p3.getsk(3, 'A', 'debug')
    # print('\n','sk0',sk[0])
    # _, _ = p3.findClosestPoint(3, 'C', 'debug')
    for i in range(len(triangles)):
        if i == 0:
            q0 = triangles[i][:, 0]
            r0 = triangles[i][:, 1]
            p0 = triangles[i][:, 2]
        else:
            q = np.hstack((q0, triangles[i][:, 0]))
            r = np.hstack((r0, triangles[i][:, 1]))
            p = np.hstack((p0, triangles[i][:, 2]))
            q0 = q
            r0 = r
            p0 = p

    A = np.hstack(((q - p), (r - p)))
    for i in range(len(sk)):
        ai = sk[i].T
        B = ai - p
        coeff = np.linalg.lstsq(A, B, None)[0]
        c = A * coeff + p
        # print(ai.shape)
        tree = KDTree(c.T, leaf_size=2)
        dis, index = tree.query(ai.T)
        print('index:', index//3)
        # true_dis = np.linalg.norm(triangles1[:, 3]-sk[0].T)
        # print('true dis:', true_dis)