import numpy as np

class LoadData:
    '''
    This class is used to load datas from the Student_Data folder.
    '''

    def __init__(self):

        return

    def loadCalbody(self, fileName):
        """
        This function returns 3 matrices (di, ai, ci) loaded from Calbody.txt
        d:8x3 a:8x3 c:27x3
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            del data[0]
            size_d = int(info[0])
            size_a = size_d + int(info[1])
            size_c = size_a + int(info[2])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            newData_d = np.mat(newData[:size_d], dtype='float')
            newData_a = np.mat(newData[size_d:size_a], dtype='float')
            newData_c = np.mat(newData[size_a:], dtype='float')
        return newData_d, newData_a, newData_c


    def loadCalreadings(self, fileName):
        """
        This function returns 3 matrices (D, A, C) loaded from Calreadings.txt
        D: 8*8x3 A: 8*8x3 C:27*8x3
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            num = int(info[3])  # number of frames
            del data[0]
            size_D = int(info[0])
            size_A = size_D + int(info[1])
            size_C = size_A + int(info[2])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            for i in range(num):
                if i == 0:
                    newData_D0 = np.mat(newData[size_C * i:size_C * i + size_D], dtype='float')
                    newData_A0 = np.mat(newData[size_C * i + size_D:size_C * i + size_A], dtype='float')
                    newData_C0 = np.mat(newData[size_C * i + size_A:size_C * i + size_C], dtype='float')
                else:
                    newData_D = np.vstack((newData_D0, np.mat(newData[size_C * i:size_C * i + size_D], dtype='float')))
                    newData_A = np.vstack(
                        (newData_A0, np.mat(newData[size_C * i + size_D:size_C * i + size_A], dtype='float')))
                    newData_C = np.vstack(
                        (newData_C0, np.mat(newData[size_C * i + size_A:size_C * i + size_C], dtype='float')))
                    newData_D0 = newData_D
                    newData_A0 = newData_A
                    newData_C0 = newData_C
        return newData_D, newData_A, newData_C


    def loadEmpivot(self, fileName):
        """
        This function returns matrices of G loaded from empivot.txt
        G: 6*12x3
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        newData_G = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            num = int(info[1])  # number of frames
            del data[0]
            size_G = int(info[0])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            for i in range(num):
                if i == 0:
                    newData_G0 = np.mat(newData[size_G * i:size_G * (i + 1)], dtype='float')
                else:
                    newData_G = np.vstack((newData_G0, np.mat(newData[size_G * i:size_G * (i + 1)], dtype='float')))
                    newData_G0 = newData_G
        return newData_G


    def loadOptpivot(self, fileName):
        """
        This function returns 2 matrices (D, H) loaded from optpivot.txt
        D:8*12x3 H:6*12x3
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        newData_D = []
        newData_H = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            num = int(info[2])  # number of frames
            del data[0]
            size_D = int(info[0])
            size_H = size_D + int(info[1])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            for i in range(num):
                if i == 0:
                    newData_D0 = np.mat(newData[size_H * i:size_H * i + size_D], dtype='float')
                    newData_H0 = np.mat(newData[size_H * i + size_D:size_H * (i + 1)], dtype='float')
                else:
                    newData_D = np.vstack((newData_D0, np.mat(newData[size_H * i:size_H * i + size_D], dtype='float')))
                    newData_H = np.vstack(
                        (newData_H0, np.mat(newData[size_H * i + size_D:size_H * (i + 1)], dtype='float')))
                    newData_D0 = newData_D
                    newData_H0 = newData_H
        return newData_D, newData_H

    def loadCtFiducial(self, fileName):
        """
        This function returns matrices of G loaded from ct-fiducials.txt
        b: 6x3
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            del data[0]
            size_b = int(info[0])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            newData_b = np.mat(newData[0:size_b], dtype='float')
        return newData_b

    def loadOutput(self, fileName):
        """
        This function returns matrices of  EM probe pivot calibration,
        optical probe pivot calibration, and C_expected loaded from output.txt
        """
        fileName = 'Student_Data/' + fileName
        newData = []
        newData_C = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            num_frame = int(info[1])  # number of frames
            pd_EM = np.mat(data[1])
            pd_Op = np.mat(data[2])
            del data[0:3]
            size_C = int(info[0])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            for i in range(num_frame):
                if i == 0:
                    newData_C0 = np.mat(newData[size_C * i:size_C * (i + 1)], dtype='float')
                else:
                    newData_C = np.vstack((newData_C0, np.mat(newData[size_C * i:size_C * (i + 1)], dtype='float')))
                    newData_C0 = newData_C
        return pd_EM, pd_Op, newData_C

    def loadOutput2(self, fileName):
        '''
        load the output2.txt data for program 2.
        @param fileName: output2.txt
        @return v: fiducials coordinates.
        '''
        fileName = 'Student_Data/' + fileName
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            del data[0]
            size_b = int(info[0])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            # take a transpose
            v = np.mat(newData[0:size_b], dtype='float')
        return v

    def OutputData(self, i, content):
        """
        This function output datas in the format identical to the given output1.txt files.
        @param: i is outpath index.
        """

        index = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10}
        debug_index = ['debug-a', 'debug-b', 'debug-c', 'debug-d', 'debug-e', 'debug-f', 'debug-g']
        unknown_index = ['unknown-h', 'unknown-i', 'unknown-j', 'unknown-k']
        if i in ['a', 'b', 'c', 'd', 'e', 'f', 'g']:
            file = debug_index[index[i]]
        elif i in ['h', 'i', 'j', 'k']:
            file = unknown_index[index[i] - len(debug_index)]
        else:
            print('Wrong index of file, Try again!')
            return
        fileName = 'pa1-' + file + '-output1-teamVersion.txt'
        Outpath = 'OUTPUT/' + fileName
        content = '27, 8, '+fileName +'\n'+ content
        with open(Outpath, 'w') as f:
            f.write(content)

    def OutputData2(self, i, content):
        """
            This function output datas in the format identical to the given output2.txt files.
             @param: i is outpath index.
        """

        index = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9}
        debug_index = ['debug-a', 'debug-b', 'debug-c', 'debug-d', 'debug-e', 'debug-f']
        unknown_index = ['unknown-g', 'unknown-h', 'unknown-i', 'unknown-j']
        if i in ['a', 'b', 'c', 'd', 'e', 'f']:
            file = debug_index[index[i]]
        elif i in ['g', 'h', 'i', 'j']:
            file = unknown_index[index[i] - len(debug_index)]
        else:
            print('Wrong index of file, Try again!')
            return
        fileName = 'pa1-' + file + '-output2-teamVersion.txt'
        Outpath = 'OUTPUT2/' + fileName
        content = '4, ' + fileName + '\n' + content
        with open(Outpath, 'w') as f:
            f.write(content)