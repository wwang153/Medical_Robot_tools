================================================
@Auther: Hongchao Shu, Wenpeng Wang
@Email: hshu4@jhu.edu 
@October 28, 2021
================================================
solvers.py
#This is a file that contains a class called Solvers.
#Solvers has several methods:
#1. Using K.Arun method to solve  3D point set to 3D point set registration.
#2. Using direct iteration method to solve the same registration.
#3. Pivot calibration for EM tracking probe.
#4. Pivot calibration for Optical tracking probe.

transformation_solvers.py
#This is a package with few useful method to do 3D frame transformations.

loadData.py
#This file contains a class LoadData which loads all data from Student_Data folder.

Assignment1.py
#This is a executable file to get outputs and do some validation.
#You can run the program by running the main in this file.

=================================================
@Update for programming 2
@Auther: Hongchao Shu, Wenpeng Wang
@Email: hshu4@jhu.edu 
@November 9, 2021
=================================================
solvers.py
#1. Update pivotCalibration_EM_helper method to return placement from mean point to marker in frame 1
 and return placement from pointer to tip.
#2. Develop bernsteinPoly_5order method to get a list of 6 part in 5-order bernstein polynomial.
#3. Develop getF method to caculate tensor form F matrix.
#4. Develop normalize method to perform min-max normalization.

loadData.py
#1.Develop loadOutput2 method to load fiducial coordinates.
#2.Develop OutputData2 method to  write our data into OUTPUT2 folder.
#3.Develop loadCtFiducial method to load G from ct-fiducial file.

Assignment2.py
#This is a executable file to get outputs and do error validation.
#You can run the program by running the main in this file.
#Goal is to get tip locations with respect to the CT image.

unitTest.py
#Add unit test files to verify the correctness of methods,
#including all new methods updated.