from loadData import LoadData
from solvers import Solvers
import Assignment1 as A1
import numpy as np
import unitTest as UT
from transformation_solvers import Transformation

ld = LoadData()
sol = Solvers()
trans = Transformation()

def problem1_Ci(fileName_calbody, fileName_calreadings):
    '''
    same as assignment1.
    @param fileName_calbody: load C in calbody.
    @param fileName_calreadings: load data in calreadings.txt
    @return C_E: the expected C.
    '''
    C_E = A1.problem4_Arun(fileName_calbody,fileName_calreadings)
    # print(C_E)
    return C_E


def problem2_DistortionCorrection(fileName_calbody, fileName_calreadings):
    '''
    Using 5 order Bernstein polynomial as distortion correction function.
    @param fileName_calbody: load C in calbody.txt.
    @param fileName_calreadings: load data in calreadings.txt to get C_E
    @return w: the distortion correction coefficient.
    '''
    _, _, C = ld.loadCalreadings(fileName_calreadings)
    # print(C)
    C_E = problem1_Ci(fileName_calbody, fileName_calreadings)
    C_x, C_y, C_z = C[:, 0], C[:, 1], C[:, 2]
    C_max = 800
    C_min = 80
    # C_max = np.max(C)
    # C_min = np.min(C)
    # each column normalize
    C_x = sol.normalize(C_x, C_max, C_min)
    C_y = sol.normalize(C_y, C_max, C_min)
    C_z = sol.normalize(C_z, C_max, C_min)

    F = sol.getF(C_x, C_y, C_z)
    #solve the least-square
    w = np.linalg.lstsq(F, C_E, None)[0]
    # print('\n F',F.shape)
    # print('fw - C_e',F*w - C_E)
    return w

def problem3_Calibration(fileName_calbody, fileName_calreadings, fileName_empivot):
    '''
    Get the corrected G and calibrate pdimple after correction.
    @param fileName_calbody: load data to caculate distortion coefficient.
    @param fileName_calreadings: load data to caculat distortion coefficient.
    @param fileName_empivot: load data to get G for pivot calibration.
    @return G_e: G after distortion correction.
    @return pdimple: dimple calibration after distortion correction.
    '''
    G = ld.loadEmpivot(fileName_empivot)
    G_max = 800
    G_min = 80
    G_x, G_y, G_z = G[:, 0], G[:, 1], G[:, 2]
    G_x = sol.normalize(G_x, G_max, G_min)
    G_y = sol.normalize(G_y, G_max, G_min)
    G_z = sol.normalize(G_z, G_max, G_min)
    F = sol.getF(G_x, G_y, G_z)
    w = problem2_DistortionCorrection(fileName_calbody, fileName_calreadings)
    G_e = np.dot(F, w)
    pdimple = sol.pivotCalibration_EM(G_e)
    # print('pdimple',pdimple)
    return G_e, pdimple

def problem4_Fiducials_Calibration(fileName_calbody, fileName_calreadings, fileName_em_fiducialss, fileName_empivot):
    '''
    Using EM markers coordinates when pointer is at some fiducials to calibrate.
    @param fileName_calbody: same as before.
    @param fileName_calreadings: same as before.
    @param fileName_em_fiducialss: Frames of Gs when pointer is at some fiducials.
    @return f: fiducials coordinates w.r.t EM base.
    '''
    G, _ = problem3_Calibration(fileName_calbody, fileName_calreadings, fileName_em_fiducialss)
    Gpivot = ld.loadEmpivot(fileName_empivot)
    g, p_tip = sol.pivotCalibration_EM_helper(Gpivot)
    num_frame = int(len(G) / 6)
    for i in range(num_frame):
        if i == 0:
            F_ptr = sol.solvePointCloudReg_Arun(g, G[6*i:6*(i+1)])
            f0 = np.mat(trans.mulF_p(F_ptr, p_tip).T)
        else:
            F_ptr = sol.solvePointCloudReg_Arun(g, G[6 * i:6 * (i + 1)])
            f = np.vstack((f0, np.mat(trans.mulF_p(F_ptr, p_tip).T)))
            f0 = f
    # print('f',f)
    return f

# def test2():
#     Gpivot = ld.loadEmpivot('pa2-debug-a-empivot.txt')
#     g, p_tip = sol.pivotCalibration_EM_helper(Gpivot)
#     G = ld.loadEmpivot('pa2-debug-a-em-fiducialss.txt')
#     F_ptr = sol.solvePointCloudReg_Arun(g, G[:6])
#     f = trans.mulF_p(F_ptr, p_tip)
#     print('f',f)

def problem5_Freg(fileName_calbody, fileName_calreadings,fileName_em_fiducialss, fileName_ct_fiducials,
                  fileName_empivot):
    '''
    Using point cloud registration to solve Freg
    Freg * f = b
    @param fileName_xxxx: files needed as before.
    @return Freg: registration frame from EM base to pointer.
    '''
    b = ld.loadCtFiducial(fileName_ct_fiducials)
    f = problem4_Fiducials_Calibration(fileName_calbody, fileName_calreadings, fileName_em_fiducialss,
                                       fileName_empivot)
    Freg = sol.solvePointCloudReg_Arun(f, b)
    # print(Freg[0])
    # print(Freg[1])
    return Freg

def problem6_TipLocation(fileName_calbody, fileName_calreadings,fileName_em_fiducialss, fileName_ct_fiducials,
                         fileName_em_nav, fileName_empivot):
    '''
    Using Freg and f obtained from last problem, get v from v = Freg * f
    @param fileName_xxx : files needed as before.
    @return v: tip location with respect to the CT image.
    '''
    Freg = problem5_Freg(fileName_calbody, fileName_calreadings,fileName_em_fiducialss, fileName_ct_fiducials,
                         fileName_empivot)
    f = problem4_Fiducials_Calibration(fileName_calbody, fileName_calreadings, fileName_em_nav, fileName_empivot)
    for i in range(len(f)):
        if i == 0:
            v0 = trans.mulF_p(Freg, f[0].T).T
        else:
            v = np.vstack((v0, trans.mulF_p(Freg, f[i].T).T))
            v0 = v
    return v

def error_verify(i):
    '''
    print out error of p_dimple, v respectively
    @param i: Index of file which needs to be verified.
    '''

    index = {'a':0, 'b':1, 'c':2, 'd':3, 'e':4, 'f':5, 'g':6, 'h':7, 'i':8, 'j':9}
    debug_index = ['debug-a', 'debug-b', 'debug-c', 'debug-d', 'debug-e', 'debug-f']
    unknown_index = ['unknown-g', 'unknown-h', 'unknown-i', 'unknown-j']
    if i in ['a','b','c','d','e','f']:
        file = debug_index[index[i]]
    elif i in ['g', 'h', 'i', 'j']:
        file = unknown_index[index[i] - len(debug_index)]
    else:
        print('Wrong index of file, Try again!')
        return

    # load the output data
    p_EM, _, _ = ld.loadOutput('pa2-' + file + '-output1.txt')
    v = ld.loadOutput2('pa2-' + file + '-output2.txt')

    # outputs from our implementations
    _, p_dimple = problem3_Calibration('pa2-' + file + '-calbody.txt', 'pa2-' + file + '-calreadings.txt',
                                    'pa2-'+file+'-empivot.txt')
    v_2 = problem6_TipLocation('pa2-' + file + '-calbody.txt', 'pa2-' + file + '-calreadings.txt',
                               'pa2-' + file + '-em-fiducialss.txt', 'pa2-' + file + '-ct-fiducials.txt',
                               'pa2-' + file + '-EM-nav.txt', 'pa2-'+file+'-empivot.txt')
    # error of p_dimple
    error_p = p_dimple.T - p_EM
    error_v = sum(v_2 - v) / len(v)
    print('error_p','\n',error_p)
    print('error_v', '\n',error_v)


def output_Data2():
    '''
    @return: generate output files which are in same format with given output1.txt
    to OUTPUT2 folder.
    '''
    index = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9}
    debug_index = ['debug-a', 'debug-b', 'debug-c', 'debug-d', 'debug-e', 'debug-f']
    unknown_index = ['unknown-g', 'unknown-h', 'unknown-i', 'unknown-j']
    file = {'a':'debug-a', 'b':'debug-b', 'c':'debug-c', 'd':'debug-d', 'e':'debug-e', 'f':'debug-f',
            'g':'unknown-g', 'h':'unknown-h', 'i':'unknown-i', 'j':'unknown-j'}
    for i in index:
        v_2 = problem6_TipLocation('pa2-' + file[i] + '-calbody.txt', 'pa2-' + file[i] + '-calreadings.txt',
                               'pa2-' + file[i] + '-em-fiducialss.txt', 'pa2-' + file[i] + '-ct-fiducials.txt',
                               'pa2-' + file[i] + '-EM-nav.txt', 'pa2-' + file[i] +'-empivot.txt')
        ld.OutputData2(i, str(v_2))

if __name__ == '__main__':
    # problem1_Ci('pa2-debug-a-calbody.txt','pa2-debug-a-calreadings.txt')
    # problem3_Calibration('pa2-debug-b-calbody.txt','pa2-debug-b-calreadings.txt', 'pa2-debug-b-empivot.txt')
    # problem2_DistortionCorrection('pa2-debug-a-calbody.txt', 'pa2-debug-a-calreadings.txt')
    # problem4_Fiducials_Calibration('pa2-debug-a-calbody.txt', 'pa2-debug-a-calreadings.txt',
    # 'pa2-debug-a-em-fiducialss.txt', 'pa2-debug-a-empivot.txt')
    # problem5_Freg('pa2-debug-b-calbody.txt', 'pa2-debug-b-calreadings.txt','pa2-debug-b-em-fiducialss.txt',
    #               'pa2-debug-b-ct-fiducials.txt','pa2-debug-b-empivot.txt')
    # problem6_TipLocation('pa2-debug-a-calbody.txt', 'pa2-debug-a-calreadings.txt','pa2-debug-a-em-fiducialss.txt',
    #                      'pa2-debug-a-ct-fiducials.txt', 'pa2-debug-a-EM-nav.txt', 'pa2-debug-a-empivot.txt')

    #Run the unit test first
    UT.runUnitTest()
    # show the error of specific dataset
    v_2 = error_verify('d')
    # write output2 data into OUTPUT2 folder
    output_Data2()
    print('Done!')