import numpy as np
from solvers import Solvers
from loadData import LoadData

sol = Solvers()
load = LoadData()

def problem4_Arun(fileName_calbody, fileName_calreadings):
    '''
    @param: fileName_calbody: 'pa1-debug-x-calreadings.txt'
    @:param: fileName_calreadings: 'pa1-debug-x-calbody.txt'
    @return: C_expected
    '''
    #load data
    D, A, C = load.loadCalreadings(fileName_calreadings)
    d, a, c = load.loadCalbody(fileName_calbody)
    num_frame = int(len(D) / len(d))
    num_D = len(d)
    num_A = len(a)
    for i in range(num_frame):
        RD, pD = sol.solvePointCloudReg_Arun(d, D[num_D*i:num_D*i+8])
        RA, pA = sol.solvePointCloudReg_Arun(a, A[num_A*i:num_A*i+8])
        for j in range(len(c)):
            if j == 0 and i == 0:
                C0 = RD.T.dot(RA * c[j].T + pA - pD).T
            else:
                C = np.vstack((C0, RD.T.dot(RA * c[j].T + pA - pD).T))
                C0 = C
    # print("C",C)
    return C

def problem4_IterF(fileName_calbody, fileName_calreadings):
    '''
    @param: fileName_calbody: 'pa1-debug-x-calreadings.txt'
    @param: fileName_calreadings: 'pa1-debug-x-calbody.txt'
    @return: C_expected
    '''
    #load data
    sol = Solvers()
    D, A, C = load.loadCalreadings(fileName_calreadings)
    d, a, c = load.loadCalbody(fileName_calbody)
    num_frame = int(len(D) / len(d))
    for i in range(num_frame):
        FD = sol.solvePointCloudReg_IterF(d, D[num_frame*i:num_frame*i+8])
        RD, pD = FD[0], FD[1]
        FA = sol.solvePointCloudReg_IterF(a, A[num_frame*i:num_frame*i+8])
        RA, pA = FA[0], FA[1]
        for j in range(len(c)):
            if j == 0 and i == 0:
                C0 = RD.T.dot(RA * c[j].T + pA - pD).T
            else:
                C = np.vstack((C0, RD.T.dot(RA * c[j].T + pA - pD).T))
                C0 = C
    return C

def problem5_EM(fileName_empivot):
    '''
    @param fileName_empivot:'pa1-debug-x-empivot.txt'
    @return: p_dimple w.r.t EM tracker 3x1
    '''
    sol = Solvers()
    G = load.loadEmpivot(fileName_empivot)
    p_dimple = sol.pivotCalibration_EM(G)
    return p_dimple


def problem6_Optical(fileName_calbody, fileName_optpivot):
    '''
    @param fileName_optpivot:'pa1-debug-x-optpivot.txt'
    @return: p_dimple w.r.t Optical tracker 3x1
    '''
    sol = Solvers()
    D, H = load.loadOptpivot(fileName_optpivot)
    d, a, c = load.loadCalbody(fileName_calbody)
    p_op = sol.pivotCalibration_Optical(H, d, D)
    return p_op

def error_verify(i):
    '''
    print out error of C, p_EM, p_Op respectively
    @param i: Index of file which needs to be verified.
    '''

    index = {'a':0, 'b':1, 'c':2, 'd':3, 'e':4, 'f':5, 'g':6, 'h':7, 'i':8, 'j':9, 'k':10}
    debug_index = ['debug-a', 'debug-b', 'debug-c', 'debug-d', 'debug-e', 'debug-f', 'debug-g']
    unknown_index = ['unknown-h', 'unknown-i', 'unknown-j', 'unknown-k']
    if i in ['a','b','c','d','e','f','g']:
        file = debug_index[index[i]]
    elif i in ['h', 'i', 'j', 'k']:
        file = unknown_index[index[i] - len(debug_index)]
    else:
        print('Wrong index of file, Try again!')
        return

    # load the output data
    p_EM, p_Op, C_exp = load.loadOutput('pa1-' + file + '-output1.txt')

    # outputs from our implementations
    C1 = problem4_Arun('pa1-' + file + '-calbody.txt', 'pa1-' + file + '-calreadings.txt')
    p_dimple_EM = problem5_EM('pa1-'+file+'-empivot.txt')
    p_dimple_Op = problem6_Optical('pa1-'+file+'-calbody.txt', 'pa1-'+file+'-optpivot.txt')

    # average error of all Cs.
    error_C = sum(C1 - C_exp) / len(C1)
    # error of p_dimple_EM and p_dimple_pOp
    error_pEM = p_dimple_EM.T - p_EM
    error_pOp = p_dimple_Op.T - p_Op

    print('error_C','\n',error_C)
    print('error p_dimple EM:','\n',error_pEM)
    print('error p_dimple Optical:','\n', error_pOp,'\n')

    # print('C', '\n', C1)
    # print('p_dimple EM:', '\n', p_dimple_EM)
    # print('p_dimple Optical:', '\n', p_dimple_Op, '\n')
    return p_dimple_EM, p_dimple_Op, C1

def output_Data():
    '''
    @return: generate output files which are in same format with given output1.txt
    to OUTPUT folder.
    '''
    index = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10}
    for i in index:
        p_dimple_EM, p_dimple_Op, C1 = error_verify(i)
        load.OutputData(i, str(p_dimple_EM.T) + '\n' + str(p_dimple_Op.T) + '\n' + str(C1))

if __name__ == '__main__':
    #Print out errors for unknown data
    # index = ['h','i','j','k']
    # for i in index:
    #     print('Frame'+' '+i+':')
    #     _, _, _ = error_verify(i)

    #This is used to generate all output files
    # into OUTPUT folder
    # output_Data()

    print('Done!')