from loadData import LoadData
from solvers import Solvers
import Assignment1 as A1
import Assignment2 as A2
import numpy as np
from transformation_solvers import Transformation
import random
ld = LoadData()
sol = Solvers()
trans = Transformation()

def test1():
    '''
    Used to test influence of min-max.
    '''
    maxList = [500,600,700,800,900,1000]
    minList = [0,10,50,70,300,500]
    _, _, C = ld.loadCalreadings('pa2-debug-b-calreadings.txt')
    # print(C)
    C_E = A2.problem1_Ci('pa2-debug-b-calbody.txt', 'pa2-debug-b-calreadings.txt')
    C_x, C_y, C_z = C[:, 0], C[:, 1], C[:, 2]
    max = maxList[round(len(maxList)*random.random())-1]
    min = minList[round(len(minList)*random.random())-1]
    # print('max:',max)
    # print('min:',min)
    # C_max = np.max(C)
    # C_min = np.min(C)
    # each column normalize
    C_x = sol.normalize(C_x, max, min)
    C_y = sol.normalize(C_y, max, min)
    C_z = sol.normalize(C_z, max, min)

    F = sol.getF(C_x, C_y, C_z)
    # solve the least-square
    w = np.linalg.lstsq(F, C_E, None)[0]

    G = ld.loadEmpivot('pa2-debug-b-empivot.txt')

    G_x, G_y, G_z = G[:, 0], G[:, 1], G[:, 2]
    G_x = sol.normalize(G_x, max, min)
    G_y = sol.normalize(G_y, max, min)
    G_z = sol.normalize(G_z, max, min)
    F = sol.getF(G_x, G_y, G_z)

    G_e = np.dot(F, w)
    pdimple = sol.pivotCalibration_EM(G_e)
    # print('pdimple',pdimple)
    return G_e, pdimple

def test2():
    '''
    Generate C data to test the normalize process.
    '''
    for i in range(5):
        if i == 0:
            C0 = np.mat([i,i,i])
        else:
            C = np.vstack((C0, np.mat([i,i,i])))
            C0 = C

    C_x, C_y, C_z = C[:, 0], C[:, 1], C[:, 2]
    C_max = 5
    C_min = 0
    # each column normalize
    C_x = sol.normalize(C_x, C_max, C_min)
    C_y = sol.normalize(C_y, C_max, C_min)
    C_z = sol.normalize(C_z, C_max, C_min)
    #supposed to be C_x,y,z [[0. ][0.2][0.4][0.6][0.8]]
    # print('C_x',C_x.T)
    # print('C_y', C_y.T)
    # print('C_z', C_z.T)
    print('test for normalize process pass!')
    return C_x, C_y, C_z

def test3():
    '''
    using test2 data to test the F matrix.
    '''
    C_x, C_y, C_z = test2()
    F = sol.getF(C_x, C_y, C_z)
    # print('F',F)

def test4():
    '''
    verify the correctness of F.
    '''
    G = ld.loadEmpivot('pa2-debug-a-empivot.txt')
    G_max = 800
    G_min = 80
    G_x, G_y, G_z = G[:, 0], G[:, 1], G[:, 2]
    G_x = sol.normalize(G_x, G_max, G_min)
    G_y = sol.normalize(G_y, G_max, G_min)
    G_z = sol.normalize(G_z, G_max, G_min)
    F = sol.getF(G_x, G_y, G_z)
    w = A2.problem2_DistortionCorrection('pa2-debug-a-calbody.txt', 'pa2-debug-a-calreadings.txt')
    G_e = np.dot(F, w)
    # pdimple = sol.pivotCalibration_EM(G_e)
    #This supposed to near to 0 for each number.
    # print('G_e - G', G_e - G)
    print('test for correction pass!')
    return G_e

def test5():
    '''
    verify the correctness of Calibration method.
    '''
    for i in range(6):
        if i == 0:
            G0 = np.mat([i,i,i])
        else:
            G = np.vstack((G0, np.mat([i,i,i])))
            G0 = G
    p_true = np.mat([1.25,1.25,1.25])
    p = sol.pivotCalibration_EM(G)
    if abs(p.T[0,0] - p_true[0,0]) < 10e-3:
        print('test for Calibration pass!')

def test6():
    '''
    verify the correctness of Point Cloud Registration using Arun method.
    '''
    for i in range(18):
        if i == 0:
            G0 = np.mat([i,i,i])
        else:
            G = np.vstack((G0, np.mat([i,i,i])))
            G0 = G

    G_mean = np.mean(G[0:6], 0)
    for i in range(6):
        if i == 0:
            g0 = np.mat(G[i] - G_mean)
        else:
            g = np.vstack((g0, G[i] - G_mean))
            g0 = g
    F = sol.solvePointCloudReg_Arun(g, G)
    # print('F*g:', trans.mulF_p(F, g[0].T), G[6].T)
    if trans.mulF_p(F, g[0].T)[0] == G[6,0]:
        print('test for cloud registration pass!')

def runUnitTest():
    test1()
    test2()
    test3()
    test4()
    test5()
    test6()
    print('All test pass!')