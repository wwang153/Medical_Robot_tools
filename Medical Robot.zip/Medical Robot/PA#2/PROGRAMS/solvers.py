import numpy as np
import scipy.linalg
from transformation_solvers import Transformation

class Solvers:

    def __init__(self):
        print(' ')

    def makeSkew(self, a):
        '''
        Make a skew matrix
        given a mat
        return a np matrix
        '''
        a = a.getA()
        x,y,z = a[0][0],a[0][1],a[0][2]
        return np.mat([[0, -z, y],[z, 0, -x],[-y, x, 0]])

    def solvePointCloudReg_Arun(self, a, b):
        '''Method due to K.Arun, et. al., IEEE PAMI, Vol 9, no 5, pp 698-700, Sept 1987
            @param a: input 3nx3 np.mat b = Fa
            @param b: input 3nx3 np.mat b = Fa
            @return: R, p components of F
        '''
        a_mean = sum(a) / len(a)
        b_mean = sum(b) / len(b)
        for i in range(len(a)):
            if i == 0:
                a_hat0 = a[i] - a_mean
                b_hat0 = b[i] - b_mean
            else:
                a_hat = np.vstack((a_hat0, a[i] - a_mean))
                b_hat = np.vstack((b_hat0, b[i] - b_mean))
                a_hat0 = a_hat
                b_hat0 = b_hat
        # compute H
        H = np.mat(np.zeros([3,3]))
        for i in range(len(a)):
            H += a_hat[i].T*b_hat[i]
        U, S, Vt = np.linalg.svd(H)
        R = Vt.T*U.T
        det = np.linalg.det(R)
        if det < 0:
            V = Vt.T * np.mat([[1,0,0],[0,1,0],[0,0,-1]])
            R = V*U.T
        p = b_mean.T - R*a_mean.T
        F = [R, p]
        return F

    def solvePointCloudReg_IterF(self, d, D, tol=10e-8):
        '''
        This method using direct iterative approach.
        solve the problem of W = argmin||XW-B||^2 in closed-form
        W = (X.T*X)^(-1)*X.T*B
        W = [alpha, epsilon].T (6 x 1), B = D - d (3n x 1),
        X = [sk(-d), I] (3n x 6)    d:8x3 Di:8*8x1
        deltaF = [I + sk(alpha), epsilon]
        F_k+1 = deltaF * F_k
        @param d: input 3nx3 np.mat D = Fd
        @param D: input 3nx3 np.mat D = Fd
        @return: F, list of R and p, F = [R, p]
        '''
        L0 = 0
        iter = 0

        # initialize F
        R = np.identity(3)
        p = np.mat([[1], [1], [1]])
        dnew = d.reshape([-1, 1])
        Dnew = D[0:len(d)].reshape([-1, 1])

        # update dk = Fk*di
        while True:
            for i in range(len(d)):
                if i == 0:
                    d_up0 = np.dot(R, dnew[3 * i:3 * i + 3]).T + p.T
                else:
                    d_up = np.vstack((d_up0, np.dot(R, dnew[3 * i:3 * i + 3]).T + p.T))
                    d_up0 = d_up
            deltaF = self.helper_IterF(d_up, D)
            deltaR, epsilon = deltaF[0], deltaF[1]
            # update R and p
            R = np.dot(deltaR, R)
            p = np.dot(deltaR, p) + epsilon

            for i in range(len(d)):
                L = np.dot((np.dot(R, dnew[3 * i:3 * i + 3]) + p - Dnew[3 * i:3 * i + 3]).T,
                           (np.dot(R, dnew[3 * i:3 * i + 3]) + p - Dnew[3 * i:3 * i + 3]))
            iter += 1
            if iter > 100 or abs(L - L0) < tol:
                break
            L0 = L
        F = [R,p]
        return F

    def helper_IterF(self, d, Di):
        '''
        @param d: input 3nx3 np.mat D = Fd
        @param Di: input 3nx3 np.mat D = Fd
        @return: deltaR 3x3, epsilon 3x1
        '''
        for i in range(len(d)):
            if i ==0:
                sk_d0 = self.makeSkew(-d[i])
                I0 = np.identity(3)
            else:
                sk_d = np.vstack((sk_d0, self.makeSkew(-d[i])))
                I = np.vstack((I0, np.identity(3)))
                sk_d0 = sk_d
                I0 = I
        X = np.hstack((sk_d,I))
        b = Di.reshape((-1,1)) - d.reshape((-1,1))
        w = np.linalg.lstsq(X,b,rcond=None)[0]
        alpha = w[:3]
        epsilon = w[3:]
        deltaR = self.makeSkew(alpha.T) + np.identity(3)
        deltaF = [deltaR, epsilon]
        return deltaF

    def pivotCalibration_EM(self, G):
        '''
        @param G: 6*12x3 EM markers on probe
        @return: Estimated post position with
                EM probe pivot calibration
        '''
        num_frame = int(len(G) / 6)
        # number of G in every frame
        num_G = int(len(G)/num_frame)
        # mean point for 1st frame
        G0 = np.mean(G[0:num_G], 0)
        for i in range(num_G):
            if i == 0:
                g0 = G[i] - G0
            else:
                g = np.vstack((g0, G[i] - G0))
                g0 = g
        # get F_G for every frame
        for i in range(num_frame):
            if num_frame == 1:
                FG = self.solvePointCloudReg_Arun(g, G[num_G * i:num_G * (i + 1)])
                RG = FG[0]
                pG = FG[1]
                I = np.identity(3)
            else:
                if i == 0:
                    FG0 = self.solvePointCloudReg_Arun(g, G[num_G*i:num_G*(i+1)])
                    RG0 = FG0[0]
                    pG0 = FG0[1]
                    I0 = np.identity(3)
                else:
                    FG = self.solvePointCloudReg_Arun(g, G[num_G * i:num_G * (i + 1)])
                    RG = np.vstack((RG0, FG[0]))
                    pG = np.vstack((pG0, FG[1]))
                    I = np.vstack((I0, np.identity(3)))
                    # update
                    RG0 = RG
                    pG0 = pG
                    I0 = I

        # set a least square problem
        X = np.hstack((I,-RG))
        w = np.linalg.lstsq(X, pG, None)[0]
        p_dimple = w[:3]
        # print(p_dimple)
        return p_dimple

    def pivotCalibration_EM_helper(self, G):
        '''
        @param G: 6*12x3 EM markers on probe
        @return g: from mean point to marker in frame 1
        @return p_tip: from pointer to tip
        '''
        num_frame = int(len(G) / 6)
        # number of G in every frame
        num_G = int(len(G) / num_frame)
        # mean point for 1st frame
        G0 = np.mean(G[0:num_G], 0)
        for i in range(num_G):
            if i == 0:
                g0 = G[i] - G0
            else:
                g = np.vstack((g0, G[i] - G0))
                g0 = g
        # get F_G for every frame
        for i in range(num_frame):
            if num_frame == 1:
                FG = self.solvePointCloudReg_Arun(g, G[num_G * i:num_G * (i + 1)])
                RG = FG[0]
                pG = FG[1]
                I = np.identity(3)
            else:
                if i == 0:
                    FG0 = self.solvePointCloudReg_Arun(g, G[num_G * i:num_G * (i + 1)])
                    RG0 = FG0[0]
                    pG0 = FG0[1]
                    I0 = np.identity(3)
                else:
                    FG = self.solvePointCloudReg_Arun(g, G[num_G * i:num_G * (i + 1)])
                    RG = np.vstack((RG0, FG[0]))
                    pG = np.vstack((pG0, FG[1]))
                    I = np.vstack((I0, np.identity(3)))
                    # update
                    RG0 = RG
                    pG0 = pG
                    I0 = I

        # set a least square problem
        X = np.hstack((I, -RG))
        w = np.linalg.lstsq(X, pG, None)[0]
        p_dimple = w[:3]
        p_tip = w[3:]
        # print(p_dimple)
        return g, p_tip

    def pivotCalibration_Optical(self, H, d, D):
        '''
        @param H: optical markers on probe
        @param d: optical markers on EM base to EM
        @param D: optical markers on EM base to Op
        @return: Estimated post position with
                optical probe pivot calibration
        '''
        trans = Transformation()
        # get Hi in first frame
        num_frame = 12
        num_H = int(len(H) / num_frame)
        H1 = H[0:num_H]
        # get all F_D
        F_D = []
        for i in range(num_frame):
            F_D.append(self.solvePointCloudReg_Arun(d, D[8*i:8*(i+1)]))
        # get a F_D to transform optical beacon position into EM tracker coordinates.
        F_D0 = self.solvePointCloudReg_Arun(d, D[0:8])
        temp = np.mat([0,0,0], dtype='float')
        for i in range(num_H):
            temp += H1[i]

        # the mean point of first frame
        H0 = trans.mulF_p(trans.inv_F(F_D0), temp.T).T/ num_H
        for i in range(num_H):
            if i == 0:
                h0 = trans.mulF_p(trans.inv_F(F_D0), H1[i].T).T - H0
            else:
                h = np.vstack((h0, trans.mulF_p(trans.inv_F(F_D0), H1[i].T).T - H0))
                h0 = h

        # inv(FD)*H
        for j in range(num_frame):
            for i in range(num_H):
                if i == 0 and j == 0:
                    H_E0 = trans.mulF_p(trans.inv_F(F_D[j]), H[j*num_H+i].T).T
                else:
                    H_E = np.vstack((H_E0, trans.mulF_p(trans.inv_F(F_D[j]), H[j*num_H+i].T).T))
                    H_E0 = H_E

            # get F_H for every frame
        for i in range(num_frame):
            if i == 0:
                FH0 = self.solvePointCloudReg_Arun(h, H_E[num_H * i:num_H * (i + 1)])
                RH0 = FH0[0]
                pH0 = FH0[1]
                I0 = np.identity(3)
            else:
                FH = self.solvePointCloudReg_Arun(h, H_E[num_H * i:num_H * (i + 1)])
                RH = np.vstack((RH0, FH[0]))
                pH = np.vstack((pH0, FH[1]))
                I = np.vstack((I0, np.identity(3)))
                # update
                RH0 = RH
                pH0 = pH
                I0 = I
        # set a least square problem
        X = np.hstack((I, -RH))
        w = scipy.linalg.lstsq(X, pH, None)[0]
        p_dimple = w[:3]
        # print(p_dimple)
        return p_dimple

    def bernsteinPoly_5order(self, t):
        '''
        This method represent 5th order bernstein polynomial
        @param t: the variable in bernstein.
        @return B: list of 6 part in 5-order bernstein polynomial.
        '''
        B0 = np.power(1 - t, 5)
        B1 = 5*np.multiply(np.power(1 - t, 4), t)
        B2 = 10*np.multiply(np.power(1 - t, 3), np.power(t, 2))
        B3 = 10*np.multiply(np.power(1 - t, 2), np.power(t, 3))
        B4 = 5*np.multiply((1 - t), np.power(t, 4))
        B5 = np.power(t, 5)
        B = [B0, B1, B2, B3, B4, B5]
        return B

    def getF(self, ux, uy, uz):
        '''
        According to the lecture note, this method builds
        F matrix, for each row: F_ijk = B_i*B_j*B_k
        @param ux: a column of ux
        @param uz: a column of uy
        @param uy: a column of uz
        @return F: the F matrix we want
        '''
        Bx = self.bernsteinPoly_5order(ux)
        By = self.bernsteinPoly_5order(uy)
        Bz = self.bernsteinPoly_5order(uz)
        for i in range(6):
            for j in range(6):
                for k in range(6):
                    if i == 0 and j == 0 and k == 0:
                        F0 = np.multiply(np.multiply(Bx[i], By[j]), Bz[k])
                    else:
                        F = np.hstack((F0, np.multiply(np.multiply(Bx[i], By[j]), Bz[k])))
                        F0 = F

        # for i in range(6):
        #     if i == 0:
        #         F0 = np.multiply(np.multiply(Bx[i], By[i]), Bz[i])
        #     else:
        #         F = np.hstack((F0, np.multiply(np.multiply(Bx[i], By[i]), Bz[i])))
        #         F0 = F
        return F

    def normalize(self, column, max, min):
        '''
        max min normalize the column
        '''
        rg = (max - min)
        # rg = 500
        # return column / rg
        return (column - min) / rg