import numpy as np

class LoadData:
    '''
    This class is used to load data from the Student_Data folder.
    '''

    def __init__(self):
        return

    def loadProbelmBody(self, problemNum, index):
        """
        This function returns LED markers and tips coordinates in body coordinates loaded from ProblemX-BodyY.txt
        @param problemNum: problem number 3 or 4.
        @param index: file index A or B.
        @return markers: LED markers coordinates in body coordinates.
        @return tips: tips coordinates in body coordinates.
        """
        fileName = 'Student_Data/' + 'Problem'+str(problemNum)+'-Body' + index + '.txt'
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            del data[0]
            size_markers = int(info[0][0])
            for line in data:
                newData.append(line.split())
            # change the data to np array float type
            markers = np.mat(newData[:size_markers], dtype='float')
            tips = np.mat(newData[size_markers:], dtype='float')
        return markers, tips

    def loadSampleReadings(self, problemNum, fileIndex, dddd):
        """
        This function returns LED markers and tips coordinates in tracker coordinates loaded from
        PAV-X-dddd-SampleReadingsTest.txt
        @param problemNum: problem number 3 or 4.
        @param fileIndex: file index A to J.
        @param dddd: debug or unknown.
        @return markers: LED markers coordinates in body coordinates.
        @return tips: tips coordinates in body coordinates.
        @return size_frame: number of frames.
        """

        fileName = 'Student_Data/' + 'PA'+str(problemNum)+ '-' + fileIndex + '-' + dddd + '-SampleReadingsTest.txt'
        newData = []
        with open(fileName, 'r') as f:
            data = f.readlines()
            info = data[0].strip('\n').split(',')
            del data[0]
            size_Markers = int(info[0])
            size_frame = int(info[1])
            for line in data:
                newData.append(line.strip('\n').split(','))
            # change the data to np array float type
            for i in range(size_frame):
                if i == 0:
                    newData_A0 = np.mat(newData[16 * i:16 * i + 6], dtype='float')
                    newData_B0 = np.mat(newData[16 * i + 6:16 * i + 12], dtype='float')
                else:
                    newData_A = np.vstack(
                        (newData_A0, np.mat(newData[16 * i:16 * i + 6], dtype='float')))
                    newData_B = np.vstack(
                        (newData_B0, np.mat(newData[16 * i + 6:16 * i + 12], dtype='float')))
                    newData_A0 = newData_A
                    newData_B0 = newData_B
        return newData_A, newData_B, size_frame

    def loadMesh(self, problemNum):
        """
        This function returns arrays of xyz coordinates of vertices and vertex indices from
        ProblemXMesh.sur
        @param problemNum: problem number 3 or 4.
        @return vertex: np array with xyz coordinates of vertices in CT coordinates.
        @return indices: np array with indices of 3 vertices for each triangle.
        """
        fileName = 'Student_Data/' + 'Problem' + str(problemNum) + 'MeshFile.sur'
        with open(fileName, 'r') as f:
            data = f.readlines()
            N_vertex = int(data[0])
            N_triangle = int(data[N_vertex + 1])
            vertex = data[1:N_vertex + 1]
            vertex1 = []
            for i in vertex:
                temp = i.rstrip('\n').split(' ')
                vertex1.append(temp)
            vertex = np.array(vertex1, dtype='float')

            indices = data[N_vertex + 2:]
            indices1 = []
            indices2 = []
            templst = []
            for i2 in indices:
                temp = i2.rstrip('\n').split(' ')
                indices1.append(temp)

            for i3 in indices1:
                ind = indices1.index(i3)
                temp = indices1[ind][:3]
                indices2.append(temp)
            # print(indices2)

            indices = np.array(indices2, dtype='int')
            indices = np.asmatrix(indices)
            vertex = np.asmatrix(vertex)
            # print('vertex', type(vertex), 'indices', type(indices))
            # print(indices[0][:3])
            # print(indices)

            # indices = np.array(indices1, dtype='float')
            # print(indices)
            return vertex, indices

    def OutputData3(self, i, content):
        """
            This function output datas in the format identical to the given Output.txt files.
             @param: i is outpath index.
        """

        index = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'J': 8}
        debug_index = ['-A-Debug-Output', '-B-Debug-Output', '-C-Debug-Output', '-D-Debug-Output',
                       '-E-Debug-Output', '-F-Debug-Output']
        unknown_index = ['-G-Unknown-Output', '-H-Unknown-Output', '-J-Unknown-Output']
        if i in ['A', 'B', 'C', 'D', 'E', 'F']:
            file = debug_index[index[i]]
        elif i in ['G', 'H', 'J']:
            file = unknown_index[index[i] - len(debug_index)]
        else:
            print('Wrong index of file, Try again!')
            return
        fileName = 'PA4' + file + '.txt'
        Outpath = 'OUTPUT/' + fileName
        # content = '15 ' + fileName + '\n' + content
        # with open(Outpath, 'w') as f:
        #     content = content.replace('[', '')
        #     content = content.replace(']', '')
        #     f.write(content)
        #     print('Done with writing' + fileName)
        num = len(content)
        np.savetxt(Outpath, content, fmt='%1.3f', delimiter=' ', header=str(num) + ' ' + fileName)