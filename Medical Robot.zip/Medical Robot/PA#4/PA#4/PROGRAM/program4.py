import numpy as np
from loadData import LoadData
from solvers import Solvers
from transformation_solvers import Transformation
import test

ld = LoadData()
sol = Solvers()
trans = Transformation()

def registration_Helper(problemNum, index, y, fileIndex, dddd):
    '''
    Using point cloud registration to get F
    @param problemNum: problem number 3 or 4.
    @param index: file index A or B.
    @param dddd: unknown or debug.
    @param y: a or b.
    @param fileIndex: A to J.
    @param dddd: debug or unknown.
    @return Flist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    _, _, num_frame = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    Flist = []
    markers, tips = ld.loadProbelmBody(problemNum, index)
    for i in range(num_frame):
        Flist.append(sol.solvePointCloudReg_Arun(markers, y[6 * i:6 * (i + 1)]))
    return Flist, tips

def getFA(problemNum, fileIndex, dddd):
    '''
    Using point cloud registration to get FA
    @param problemNum: problem number 3 or 4.
    @param index: file index A or B.
    @param dddd: unknown or debug.
    @return FAlist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    a, _, numFrames = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    FAlist, Atips = registration_Helper(problemNum, 'A', a, fileIndex, dddd)
    return FAlist, Atips, numFrames

def getFB(problemNum, fileIndex, dddd):
    '''
    Using point cloud registration to get FB
    @param problemNum: problem number 3 or 4.
    @param fileIndex: file index A to J.
    @param dddd: unknown or debug.
    @return FAlist: a list of transformation from registration for each frame.
    @return tips: tips coordinates in body coordinates.
    '''
    _, b, numFrames = ld.loadSampleReadings(problemNum, fileIndex, dddd)
    FAlist, Btips = registration_Helper(problemNum, 'B', b, fileIndex, dddd)
    return FAlist, Btips, numFrames

def getdk(problemNum, fileIndex,dddd):
    '''
    @return dk: dk = FB^-1 * FA * Atip
    '''
    FA, Atip, num_frame = getFA(problemNum, fileIndex, dddd)
    FB, _, _ = getFB(problemNum, fileIndex, dddd)
    for i in range(num_frame):
        if i == 0:
            dk0 = np.mat(trans.mulF_p(trans.mulF_F(trans.inv_F(FB[0]), FA[0]), Atip.T).T)
        else:
            dk = np.vstack((dk0, np.mat(trans.mulF_p(trans.mulF_F(trans.inv_F(FB[i]), FA[i]), Atip.T).T)))
            dk0 = dk
    return dk

def getsk(F_reg, problemNum, fileIndex ,dddd):
    '''
    @return ck: ck = F_reg * dk
    '''
    #initialize Freg = I
    # R_reg = np.identity(3)
    # p_reg = np.mat([[0],[0],[0]])
    # F_reg = [R_reg, p_reg]

    dk = getdk(problemNum, fileIndex, dddd)
    for i in range(len(dk)):
        if i == 0:
            sk0 = np.mat(trans.mulF_p(F_reg, dk[0].T)).T
        else:
            sk = np.vstack((sk0, np.mat(trans.mulF_p(F_reg, dk[i].T)).T))
            sk0 = sk
    return sk

def getTriangles(problemNum):
    '''
    @param problemNum: problem 3 or 4.
    @return triangles: a list of 3x3 matrices represent 3 points
    of triangles. [point1, point2, point3]
    '''

    triangles = []
    vertcies, indices = ld.loadMesh(problemNum)
    for i in range(len(indices)):
        qindex, rindex, pindex = indices[i, 0], indices[i, 1], indices[i, 2]
        triangle = np.hstack((vertcies[qindex].T, np.hstack((vertcies[rindex].T, vertcies[pindex].T))))
        triangles.append(triangle)
    return triangles

def projectOnSeg(c, a, b):
    '''
    @param c: point on the border of triangle.
    @param a: one of 3 vertices in triangle.
    @param b: one of 3 vertices in triangle.
    @return c_star
    '''
    la = ((c - a).T*(b - a)) / ((b - a).T*(b - a))
    la_seg = max(0, min(la, 1))
    c_star = a + (b - a) * la_seg
    return c_star

def boundingBox(F_reg, problemNum, fileIndex, dddd):
    count = 0
    ck = []
    sk = getsk(F_reg, problemNum, fileIndex, dddd)
    triangles = getTriangles(problemNum)
    # bound_lower = [np.min(tri[:, 0]), np.min(tri[:, 1]), np.min(tri[:, 2])]
    # bound_upper = [np.max(tri[:, 0]), np.max(tri[:, 1]), np.max(tri[:, 2])]
    # bound_lower = [-float('inf'), -float('inf'), -float('inf')]
    # bound_upper = [float('inf'), float('inf'), float('inf')]

    for i in range(len(sk)):
        closestDis = float('inf')
        # bounding box
        for j in range(len(triangles)):
            ai = sk[i].T
            tri = triangles[j]
            bound_lower = [np.min(tri[0, :]), np.min(tri[1, :]), np.min(tri[2, :])]
            bound_upper = [np.max(tri[0, :]), np.max(tri[1, :]), np.max(tri[2, :])]
            if bound_upper[0] + closestDis >= ai[0, 0] >= bound_lower[0] - closestDis \
                    and bound_upper[1] + closestDis >= ai[1, 0] >= bound_lower[1] - closestDis \
                    and bound_upper[2] + closestDis >= ai[2, 0] >= bound_lower[2] - closestDis:
                count += 1
                ci = FindClosestPoint(sk[i], triangles[j])
                # search in brute way
                if np.linalg.norm(ai - ci) < closestDis:
                    closestPoint = ci
                    closestDis = np.linalg.norm(ai - ci)
        ck.append(closestPoint.T)

    # put ck in np matrix
    for i in range(len(ck)):
        if i == 0:
            c0 = ck[i]
        else:
            c = np.vstack((c0, ck[i]))
            c0 = c
    # difference between sk and c
    for i in range(len(ck)):
        if i == 0:
            diff0 = np.linalg.norm(sk[i] - c[i])
        else:
            diff = np.vstack((diff0, np.linalg.norm(sk[i] - c[i])))
            diff0 = diff
    print('count', count)
    return c, diff

def FindClosestPoint(sk_i, triangle_i):
    ai = sk_i.T
    q, r, p = triangle_i[:, 0], triangle_i[:, 1], triangle_i[:, 2]
    # using lstsq to solve lambda and miu
    A = np.hstack(((q - p), (r - p)))
    B = ai - p
    coeff = np.linalg.lstsq(A, B, None)[0]
    ci = A * coeff + p
    if coeff[0] >= 0 and coeff[1] >= 0 and np.sum(coeff) <= 1:
        return ci
    elif coeff[0] < 0:
        return projectOnSeg(ci, r, p)
    elif coeff[1] < 0:
        return projectOnSeg(ci, p, q)
    elif np.sum(coeff) > 1:
        return projectOnSeg(ci, q, r)

def matching(F_reg, ita, problemNum, fileIndex, dddd):
    A = []
    B = []

    dk = getdk(problemNum, fileIndex, dddd)
    # sk = getsk(F_reg, problemNum, fileIndex, dddd)
    c, diff = boundingBox(F_reg, problemNum, fileIndex, dddd)
    for i in range(len(diff)):
        if diff[i] < ita:
            A.append(dk[i])
            B.append(c[i])
    A = np.vstack(A)
    B = np.vstack(B)
    return A, B

def update(A, B):

    # find rigid transformation
    # A, B = matching(F_reg, ita, problemNum, fileIndex, dddd)
    F_reg = sol.solvePointCloudReg_Arun(A, B)
    resError = []
    epsilon_list = []
    sum1 = 0
    sum2 = 0
    for i in range(len(A)):
        resError.append(B[i].T - trans.mulF_p(F_reg, A[i].T))
    resError = np.hstack(resError)
    for j in range(len(resError)):
        e_s = resError[:, j].T * resError[:, j]
        e_sr = np.sqrt(e_s)
        epsilon_list.append(e_sr)
        sum1 += e_s
        sum2 += e_sr
    # print('ep list', epsilon_list)
    sigma = np.sqrt(sum1) / len(resError)
    epsilon_max = max(epsilon_list)
    epsilon_bar = sum2 / len(resError)
    return sigma, epsilon_max, epsilon_bar, F_reg

def ICP(problemNum, fileIndex, dddd):
    #initialize the F_reg
    R_reg = np.identity(3)
    p_reg = np.mat([[0], [0], [0]])
    F_reg = [R_reg, p_reg]

    #initialize ita
    ita = 20

    #initialize threshold
    sigma0, epsilon_max0, epsilon_bar0 = 0.1, 0.1, 1

    thres_sigma = 0.14
    thres_emax = 0.21
    gamma = 0.95
    iteration = 0
    flag = True
    while flag:
        iteration += 1
        #step 1 matching
        A, B = matching(F_reg, ita, problemNum, fileIndex, dddd)
        #step 2 update
        sigma, epsilon_max, epsilon_bar, F_reg = update(A, B)
        #step 3 adjustment
        ita = 3 * epsilon_bar
        #step 4 terminate
        if sigma < thres_sigma and epsilon_max < thres_emax  and\
            gamma <= (epsilon_bar / epsilon_bar0) <= 1 or iteration > 35:
            c, diff = boundingBox(F_reg, problemNum, fileIndex, dddd)
            sk = getsk(F_reg, problemNum, fileIndex, dddd)
            temp = np.hstack((c, diff))
            return np.hstack((sk, temp))
        else:
            print('iteration:', iteration)
            # print('sigma', sigma, '\n', 'epsilon max', epsilon_max,
            #       '\n', 'epsilon bar', epsilon_bar, 'ratio', (epsilon_bar / epsilon_bar0))
            epsilon_bar0 = epsilon_bar

def outputAll():
    '''
    Generate all outputs in OUTPUT folder.
    '''
    fileIter = 0
    index = {'A': 'debug', 'B': 'debug', 'C': 'debug', 'D': 'debug', 'E': 'debug', 'F': 'debug',
             'G': 'unknown', 'H': 'unknown', 'J': 'unknown'}
    for i in index.items():
        fileIter += 1
        icp = ICP(4, i[0], i[1])
        # np.set_printoptions(precision=3, suppress=True)
        content = icp
        ld.OutputData3(i[0], content)
        print('file'+str(fileIter)+'Output!')

if __name__ == '__main__':
    outputAll()
    print('Done!')