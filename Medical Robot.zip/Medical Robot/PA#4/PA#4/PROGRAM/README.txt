@Auther: Hongchao Shu, Wenpeng Wang
@Email: hshu4@jhu.edu, wwang153@jhu.edu 
@December 2, 2021
================================================
loadData.py
#This file contains a class LoadData which loads all data from Student_Data folder.

transformation_solvers.py
#This is a package with few useful method to do 3D frame transformations.

solvers.py
#This is a file that contains a class called Solvers.

program3.py
#This is a package for solving the programming assignment 3.
#It will not be used in this assignment.

program4.py
#This is a executable file to get outputs.
#You can run the program by running the main in this file.

test.py
#This is a file that contains all the test function for each function developed 
#in this assignment.