import numpy as np

class Transformation:
    def __init__(self):
        print('')

    def mulF_F(self, F1, F2):
        '''
        @param F1: The first F, list of [R1, p1]
        @param F2: The second F, list of [R2, p2]
        @return: new F = F1*F2, list of [R1*R2, R1*p2 + p1]
        '''
        R1, p1 = F1[0], F1[1]
        R2, p2 = F2[0], F2[1]
        Rnew = np.dot(R1, R2)
        pnew = np.dot(R1,p2) + p1
        return [Rnew, pnew]

    def mulF_p(self, F1, p):
        '''
        @param F1: The list of [R1, p1]
        @param p: The p, np matrix of 3x1
        @return: new p = F*p, R1*p + p1, np matrix
        '''
        R1, p1 = F1[0], F1[1]
        pnew = np.mat(np.dot(R1,p) + p1)
        return pnew

    def inv_F(self,F):
        '''
        @param F: The list of [R, p]
        @return: new a inverse F, list of [R.T, -R.T*p]
        '''
        R, p = F[0], F[1]
        Rnew = np.mat(R.T)
        pnew = np.mat(np.dot(-R.T, p))
        return [Rnew, pnew]

    def makeSkew(self, a):
        '''
        Make a skew matrix
        @param a: given a mat
        @return: a np matrix
        '''
        a = a.getA()
        x,y,z = a[0][0],a[0][1],a[0][2]
        return np.mat([[0, -z, y],[z, 0, -x],[-y, x, 0]])