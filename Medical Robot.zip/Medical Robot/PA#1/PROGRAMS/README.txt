@Auther: Hongchao Shu, Wenpeng Wang
@Email: hshu4@jhu.edu 
@October 28, 2021
================================================
solvers.py
#This is a file that contains a class called Solvers.
#Solvers has several methods:
#1. Using K.Arun method to solve  3D point set to 3D point set registration.
#2. Using direct iteration method to solve the same registration.
#3. Pivot calibration for EM tracking probe.
#4. Pivot calibration for Optical tracking probe.

transformation_solvers.py
#This is a package with few useful method to do 3D frame transformations.

loadData.py
#This file contains a class LoadData which loads all data from Student_Data folder.

Assignment1.py
#This is a executable file to get outputs and do some validation.
#You can run the program by running the main in this file.